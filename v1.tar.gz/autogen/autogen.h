#ifndef ___AUTO_GEN_H
#define ___AUTO_GEN_H
#endif
