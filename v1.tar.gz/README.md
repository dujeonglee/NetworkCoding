# NetworkCoding
## Implementation of network coding data transportation.
## Example code can be found in main.cpp.

# Contributions
## I welcome any contributions from you.
